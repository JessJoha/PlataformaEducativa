# Create Evaluation Microservice

## Overview

The **Create Evaluation** microservice is responsible for handling the creation of new evaluations within the platform. It allows users to define evaluations, including their questions and options, and stores them in the database.

## Features

- Create new evaluations with a name, description, and associated questions.
- Store evaluation data in the database.
- Ensure proper validation of input data.

## Technology Stack

- **Node.js** (Backend runtime)
- **Express.js** (Web framework)
- **MySQL** (Database)
- **Sequelize** (ORM for database interaction)

## Database Configuration

This microservice connects to a **MySQL database** using Sequelize. The configuration details are found in `db.js` under the `config` directory.

## API Endpoints

**Method**
POST

**Endpoint**
/evaluations/create

**Description**
Creates a new evaluation

## Related Microservices

- **UserManagement** (Handles user operations)
- **Login** (Authenticates users)
- **CoursesManagement** (Handles courses, which may include evaluations)

## Data Flow

1. A request is sent to the `/evaluations/create` endpoint with evaluation details.
2. The service validates the input data.
3. If the data is valid, the new evaluation is inserted into the MySQL database.
4. The response returns a success message or an error if any issue occurs.

## Installation & Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/JessJoha/PlataformaEducativa.git
   ```
2. Navigate to the microservice directory:
   ```bash
   cd backend/EvaluationsManagement/createEvaluation
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Configure environment variables in a `.env` file.
5. Start the service:
   ```bash
   npm start
   ```

## Deployment

This microservice is deployed using **Docker** and **GitHub Actions**. The deployment process includes:

- Building the Docker image.
- Pushing the image to DockerHub.
- Pulling and running the container on an AWS EC2 instance.

## Environment Variables

Ensure the following environment variables are set:

```
DB_HOST=<database_host>
DB_USER=<database_user>
DB_PASSWORD=<database_password>
DB_NAME=<database_name>
```