const reportWebVitals = (metric) => {
    console.log(metric);
  };
  export default reportWebVitals;